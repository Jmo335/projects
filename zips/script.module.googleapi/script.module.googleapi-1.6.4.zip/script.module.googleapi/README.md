script.module.googleapi
=======================

An XBMC addon that wraps up the official Google API python classes (https://github.com/google/google-api-python-client)

See the Google documentation for usage. Import into your XBMC addons by using "from apiclient import ...." as indicated in the Google documenation. 
