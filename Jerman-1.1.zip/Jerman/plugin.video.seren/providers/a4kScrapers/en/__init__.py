# -*- coding: utf-8 -*-

import torrent
import hosters

def get_torrent():
    return torrent.__all__

def get_hosters():
    return hosters.__all__
